
  # Design Internship App

  This is a code bundle for Design Internship App. The original project is available at https://www.figma.com/design/V4Nkb4RG9go3QNcinN2R99/Design-Internship-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  